#!/bin/bash -v

# Stop the firewall to allow communication with the nodes
# TODO: find the exact ports to open
sudo systemctl stop firewalld

# Add librairies
sudo yum install -y libSM libX11 libXext libXt

# Disable Hyperthreading
sudo chmod 777 /mnt/share/disable_ht.sh
sudo /mnt/share/disable_ht.sh 0

cd /mnt/share

# Download and install STAR-CCM+
wget https://objectstorage.us-phoenix-1.oraclecloud.com/p/u_crBQofJkBdRvbfs_kogZg6IFDsISxJuTJMXIgkiE0/n/hpc/b/HPC_APPS/o/STAR-CCM+14.04.011_02_linux-x86_64.tar.gz -O STARCCMINSTALLER.tar.gz
tar -xf STARCCMINSTALLER.tar.gz
mkdir /mnt/share/install
/mnt/share/starccm+_14.04.011/STAR-CCM+14.04.011_02_linux-x86_64-2.12_gnu7.1.sh -i silent -DINSTALLDIR=/mnt/share/install


# Download benchmark
wget https://objectstorage.us-phoenix-1.oraclecloud.com/p/zOcMEXuYCryfrlKHstU8pzyUeBv1K5uHr35DxHnN5nc/n/hpc/b/starccm_benchmarks/o/lemans_poly_17m.amg.sim.tar
tar -xf lemans_poly_17m.amg.sim.tar

# Register the headnode as a compute node 
echo $1:36 >> /mnt/share/install/machinelist.txt


# Remove flexlm file that is causing issue if you are using the POD key
rm ~/.flexlmrc

echo done